import java.util.*;

public class Main {
    public static void main(String args[]) {
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt(),a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = ps.nextInt();
        }
        int sqc = 0, cbc = 0;
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                int sum = a[i] + a[j];
                sqc += square(sum);
                cbc += Cube(sum);
            }
        }
        int ans = sqc + cbc;
        System.out.print(ans);
    }

    public static int square(int n) {
        int sq = (int) Math.sqrt(n);
        return sq * sq == n ? 1 : 0;
    }

    public static int Cube(int n) {
        int cb = (int) Math.cbrt(n);
        return cb * cb * cb == n ? 1 : 0;
    }
}
