import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner  n = new Scanner (System.in);
        int num = n.nextInt();
        int a,arr[] = new int[num],h=0;
        Arrays.sort(arr);
        for(int i = 0 ; i<num ; i++){
            arr[i] = n.nextInt();
        }
        for(int i =0;i<num;i++)
        {  a = 0;
            int temp = arr[i];
            for(int j = 0;j<num;j++){
                if(temp==arr[j]){
                    ++a;
                }}
            if(a==1){
                System.out.print(arr[i]+" ");
            continue;
        }
             else{
            System.out.print("No unique elements");
            break;
    }}
}}


