//Given an array of integers of size ‘n’, Our aim is to calculate the maximum sum of ‘k’ consecutive elements in the array.
import java.util.*;
public class Main {
	public static int maxSum(int arr[], int n, int k)
	{
		int res = 0;
		for (int i=0; i<k; i++)
		res += arr[i];
		int curr_sum = res;
		for (int i=k; i<n; i++)
		{
		curr_sum += arr[i] - arr[i-k];
		res = Math.max(res, curr_sum);
		}
		return res;
	}
	public static void main(String[] args)
	{
	    Scanner pk = new Scanner(System.in);
        int a = pk.nextInt();
        int arr[] = new int[a];
        for(int i=0; i<a; i++)
            arr[i] = pk.nextInt();
		int k = pk.nextInt();
		int n = arr.length;
		if (n < k)
		{
		    System.out.println("Invalid");
		    return;
		}
		System.out.println(maxSum(arr, n, k));
	}
}
