import java.util.*;
public class Permute{
    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt(),a[] = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = ps.nextInt();
        }
        int k = ps.nextInt();
        ArrayList<Integer> t1 = new ArrayList<>();
        boolean temp = false;
        for (int i = 0; i < n; i++) {
            int sum = 0;
            t1.clear();
            for (int j = i; j < n; j++) {
                sum += a[j];
                t1.add(a[j]);
                if (sum == k) {
                    for(int o : t1){
                        System.out.print(o + " ");
                    }
                    temp = true;
                    break;
                }
            }
            if(temp)
                break;
        }
        if (!temp) {
            System.out.println("-1");
        }
    }
}