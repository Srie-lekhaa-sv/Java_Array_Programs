/*/*
Write a program which performs the following operations on the array
For given N elements
1) Find the index of the second largest element in the array
2) Find the maximum occurring element in the array. If there are more than one maximum occurring elements, the lowest value element should be returned
3) Insert 17 in the 3rd position and find the sum of the first 5 elements in the array

For example:

Input

10
10
30
40
50

Result

10
107
21
*/
import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps=new Scanner(System.in);
        int n=ps.nextInt();
        int sum=17;
        ArrayList<Integer>t1=new ArrayList<Integer>();
        int b[]=new int[n];
        for(int i=0;i<n;i++){
        t1.add(ps.nextInt());
        b[i]=t1.get(i);
        if(i<4)
        sum=sum+b[i];}
        Arrays.sort(b);
        int d=0,h=0,num=0;
        for(int i=b.length-2;i>=0;i--){
        if(b[i]<b[b.length-1]){
        num=b[i];
        break;}}
        System.out.println(t1.indexOf(num));
        for(int i=0;i<n;i++){
        int c=0;
        for(int j=0;j<n;j++){
        if(b[i]==b[j])
        c++;}
        if(c>d){
        d=c;
        h=b[i];}
        else if(c==d){
        if(h>b[i])
        h=b[i];}
        }
        System.out.println(h);
        System.out.println(sum);
    }
}