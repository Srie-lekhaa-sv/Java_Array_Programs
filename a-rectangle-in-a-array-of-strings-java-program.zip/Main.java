import java.util.*;
public class Main {
    static int count = 0;
    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt();
        String s[] = new String[n], s2 = "";
        String a[][] = new String[n][n];
        for (int i = 0; i < n; i++) {
            s[i] = ps.next();
            s2 += s[i];
        }
        if (!s2.contains("A")) {
            System.out.println("0");
            return;
        }
        String s3[] = s2.split("");
        int c = 0;
        for (int k = 0; k < n; k++) {
            for (int j = 0; j < n; j++) {
                a[k][j] = s2.charAt(c) + "";
                c++;
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j].equals("A")) {
                    int rect = soln(a, n, i, j);
                    count = Math.max(count, rect);
                }
            }
        }
        System.out.println(count);
    }
    public static int soln(String ar[][], int n, int p, int s) {
        int k = 0;
        int l = 0;
        for (int i = p; i < n && ar[i][s].equals("A"); i++) {
            k++;
        }
        for (int j = s; j < n && ar[p][j].equals("A"); j++) {
            l++;
        }
        return k * l;
    }
}