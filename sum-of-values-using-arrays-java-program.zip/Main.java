import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt(),a[] = new int[n],b[] = new int[n];
        for(int i = 0;i<n;i++){
            a[i] = ps.nextInt();
        }
        for(int i = 0;i<n;i++){
            b[i] = ps.nextInt();
        }
        for(int i = 0;i<n;i++){
            System.out.print((a[i]+b[i])+" ");
        }
    }
}